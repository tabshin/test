This is the WIN32 Release of Wput.
See the doc/ directory for manpage and additional documentation.
The OpenSSL-DLLs are only required for wput to support encrypted
FTP-transactions, it will run without them as well. They are not
part of wput, but are included for easier use.

Homepage: http://wput.sf.net
Version: 0.6-win32
